public class DataTypes {
    public static void main(String[] args) {
        boolean flag = true;
        int a = 12345;
        short s = 1200;
        byte b = 120;
        long l = 832786310;
        float f = 800.7692f;
        double d = 7878.8765;
        char ch = 'p';

        System.out.println("The boolean variable is " + flag);
        System.out.println("The integer variable is " + a);
        System.out.println("The short variable is " + s);
        System.out.println("The byte variable is " + b);
        System.out.println("The long variable is " + l);
        System.out.println("The float variable is " + f);
        System.out.println("The double variable is " + d);
        System.out.println("The char variable is " + ch);
    }
}
