class HelloWorld {
    public static void main(String[] args) {
        int money = 2000;
        System.out.println(money);
        money = 5000;
        System.out.println(money);
    }
}
