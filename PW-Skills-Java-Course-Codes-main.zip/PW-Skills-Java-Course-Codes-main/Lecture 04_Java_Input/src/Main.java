import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner sc = new Scanner(System.in);
        String p = sc.next();
        int q = sc.nextInt();
        System.out.print(p + " " + q);

    }
}