public class ArithmeticOperators {
    public static void main(String[] args) {
        int p = 20, q = 10;

        System.out.println(p+q);
        System.out.println(p-q);
        System.out.println(p*q);
        System.out.println(p/q);
        System.out.println(p%q);

    }
}
