public class Main {
    public static void main(String[] args) {
        int p = 4, q = 3, r = 2;
        System.out.println(p-++r-++q);
        System.out.println(6 + "pqr");
    }
}