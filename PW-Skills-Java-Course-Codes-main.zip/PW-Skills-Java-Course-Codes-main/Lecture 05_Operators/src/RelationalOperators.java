public class RelationalOperators {
    public static void main(String[] args) {
        int p = 10, q = 15;

        System.out.println(p == q); //false
        System.out.println(p != q); //true
        System.out.println(p <= q); //true
        System.out.println(p >= q); //false
        System.out.println(p < q); //true
        System.out.println(p > q); //false

    }
}
