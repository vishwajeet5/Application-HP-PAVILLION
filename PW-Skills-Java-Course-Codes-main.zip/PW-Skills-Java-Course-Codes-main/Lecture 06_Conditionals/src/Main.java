public class Main {
    public static void main(String[] args) {
        int x = 60, y = 90;
        if (y % x == 0)
            System.out.println("Good");
        else
            System.out.println("Bad");
    }
}