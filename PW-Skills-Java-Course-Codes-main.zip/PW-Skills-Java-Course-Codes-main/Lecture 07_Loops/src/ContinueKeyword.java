public class ContinueKeyword {
    public static void main(String[] args) {

//        outer: for(int i = 0; i < 10; i++){
//            inner: for(int j = 0; j < 5; j++){
//                break outer;
//            }
//        }

//        myloop: for(int num = 1; num <= 50; num++){
//            if(num % 3 == 0){
//                continue myloop;
//            }
//            System.out.println(num);
//        }

//        int num = 1;
//
//        while(num <= 50){
//            if(num % 3 == 0){
//                num++;
//                continue;
//            }
//            System.out.println(num);
//            num++;
//        }

    }
}
