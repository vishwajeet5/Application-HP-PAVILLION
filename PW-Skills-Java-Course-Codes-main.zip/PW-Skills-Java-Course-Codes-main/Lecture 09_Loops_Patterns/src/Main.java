public class Main {
    public static void main(String[] args) {
        float p = 34.5f;
        float r = 2.2f;
        float t = 3.5f;

        float si = ((p*r*t)/100);
        System.out.println(si);


//        int a[] = { 1, 4, 7, 9 };
//
//        int n = a.length;
//        int b[] = a;
//
////        b = a;
//
//        b[0] = 5;
//
//        System.out.println("Original array ");
//        for (int i = 0; i < n; i++)
//            System.out.print(a[i] + " ");
//
//        System.out.println("\nReferenced Array ");
//        for (int i = 0; i < n; i++)
//            System.out.print(b[i] + " ");

//        double[] wts = new double[3];
//        float[] heights = {5.5f, 5.0f, 6.5f};
//
//        int marks[] = new int[3];
//        String[] names = {"Meeta", "Shivangi", "Meghna"};
//
//        wts[0] = 56.82;
//        wts[1] = 45.9;
//
//        marks[0] = 2;
//        marks[1] = 3;
//
//        System.out.println("Names: ");
//        for(int i = 0; i < 3; i++){ //names.length
//            System.out.println(names[i]);
//        }
//
//        System.out.println("Weights: ");
//        for(int i = 0; i < 3; i++){ //weights.length
//            System.out.println(wts[i]);
//        }
//
//        System.out.println("Marks: ");
//        for(int i = 0; i < 3; i++){
//            System.out.println(marks[i]);
//        }
//
//        System.out.println("Heights: ");
//        for(int i = 0; i < 3; i++){
//            System.out.println(heights[i]);
//        }
//
//        for(int i = 0; i < 3; i++){
////            System.out.println(names[i] + ": " + wts[i] + ", " + heights[i] + ", " + marks[i]);
//            System.out.printf("Name: %s, Weight: %f, Height: %f, Marks: %d \n", names[i], wts[i], heights[i], marks[i]);
//        }


//        System.out.println(marks[-2]);
    }
}
