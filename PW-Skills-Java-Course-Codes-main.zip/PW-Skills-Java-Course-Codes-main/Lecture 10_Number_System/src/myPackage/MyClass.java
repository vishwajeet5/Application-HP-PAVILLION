package myPackage;

public class MyClass {
    public void myPrint(){
        System.out.println("This is my print from my package");
    }
}
