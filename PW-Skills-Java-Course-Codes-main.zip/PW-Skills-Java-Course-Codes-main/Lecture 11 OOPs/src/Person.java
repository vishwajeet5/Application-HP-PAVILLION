public class Person {
    int age = 20;

    public static void main(String[] args) {
        Person Rohan = new Person();
        System.out.println(Rohan.age);
    }
}
