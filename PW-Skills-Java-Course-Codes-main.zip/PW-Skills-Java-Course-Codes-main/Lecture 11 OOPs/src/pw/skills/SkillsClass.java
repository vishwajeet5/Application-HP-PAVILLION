package pw.skills;

public class SkillsClass {
}
