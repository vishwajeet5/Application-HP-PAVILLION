public class StandardLibraryDemo {
    public static void main(String[] args) {
        int num = 16;
        System.out.println(Math.sqrt(num));
    }
}
